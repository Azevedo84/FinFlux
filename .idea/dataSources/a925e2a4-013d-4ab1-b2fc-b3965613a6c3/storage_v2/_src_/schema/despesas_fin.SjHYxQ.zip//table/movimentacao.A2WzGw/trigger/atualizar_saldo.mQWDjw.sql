create definer = anderson_felipe@`%` trigger atualizar_saldo
    after insert
    on movimentacao
    for each row
BEGIN
    DECLARE saldo_atual DECIMAL(15,2);
    
    -- Obtém o saldo atual da tabela saldo_banco
    SELECT saldo INTO saldo_atual FROM saldo_banco WHERE id = NEW.id_saldo;
    
    -- Atualiza o saldo com base nas quantidades de entrada e saída
    SET saldo_atual = saldo_atual + NEW.qtde_ent - NEW.qtde_sai;
    
    -- Atualiza o saldo na tabela saldo_banco
    UPDATE saldo_banco SET saldo = saldo_atual WHERE id = NEW.id_saldo;
END;

