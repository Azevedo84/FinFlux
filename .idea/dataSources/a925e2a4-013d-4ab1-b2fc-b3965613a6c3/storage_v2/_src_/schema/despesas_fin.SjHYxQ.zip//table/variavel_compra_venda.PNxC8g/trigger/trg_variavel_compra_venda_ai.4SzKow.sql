create definer = anderson_felipe@`%` trigger trg_variavel_compra_venda_ai
    after insert
    on variavel_compra_venda
    for each row
BEGIN
    UPDATE variavel_cadastro_ativo
    SET SALDO = IFNULL(SALDO, 0) + NEW.QTDE
    WHERE ID = NEW.ID_ATIVO;
END;

