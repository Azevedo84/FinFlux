create definer = anderson_felipe@`%` trigger trg_variavel_compra_venda_au
    after update
    on variavel_compra_venda
    for each row
BEGIN
    -- Remove o valor antigo do saldo antigo
    UPDATE variavel_cadastro_ativo
    SET SALDO = IFNULL(SALDO, 0) - OLD.QTDE
    WHERE ID = OLD.ID_ATIVO;

    -- Adiciona o novo valor ao saldo novo
    UPDATE variavel_cadastro_ativo
    SET SALDO = IFNULL(SALDO, 0) + NEW.QTDE
    WHERE ID = NEW.ID_ATIVO;
END;

