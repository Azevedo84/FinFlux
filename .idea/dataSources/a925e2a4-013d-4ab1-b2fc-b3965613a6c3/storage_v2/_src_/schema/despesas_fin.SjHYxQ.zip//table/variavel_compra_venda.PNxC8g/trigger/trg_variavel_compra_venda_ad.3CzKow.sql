create definer = anderson_felipe@`%` trigger trg_variavel_compra_venda_ad
    after delete
    on variavel_compra_venda
    for each row
BEGIN
    UPDATE variavel_cadastro_ativo
    SET SALDO = IFNULL(SALDO, 0) - OLD.QTDE
    WHERE ID = OLD.ID_ATIVO;
END;

