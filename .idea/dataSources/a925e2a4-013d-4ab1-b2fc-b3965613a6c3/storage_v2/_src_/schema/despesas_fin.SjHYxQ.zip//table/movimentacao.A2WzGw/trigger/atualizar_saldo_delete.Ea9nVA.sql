create definer = anderson_felipe@`%` trigger atualizar_saldo_delete
    after delete
    on movimentacao
    for each row
BEGIN
    DECLARE saldo_atual DECIMAL(15,2);
    
    -- Obtém o saldo atual da tabela saldo_banco
    SELECT saldo INTO saldo_atual FROM saldo_banco WHERE id = OLD.id_saldo;
    
    -- Atualiza o saldo subtraindo as quantidades da movimentacao deletada
    SET saldo_atual = saldo_atual - OLD.qtde_ent + OLD.qtde_sai;
    
    -- Atualiza o saldo na tabela saldo_banco
    UPDATE saldo_banco SET saldo = saldo_atual WHERE id = OLD.id_saldo;
END;

