create definer = anderson_felipe@`%` trigger atualizar_saldo_update
    after update
    on movimentacao
    for each row
BEGIN
    DECLARE saldo_atual DECIMAL(15,2);
    
    -- Obtém o saldo atual da tabela saldo_banco
    SELECT saldo INTO saldo_atual FROM saldo_banco WHERE id = NEW.id_saldo;
    
    -- Atualiza o saldo com base nas diferenças entre os valores antigos e novos
    SET saldo_atual = saldo_atual + NEW.qtde_ent - OLD.qtde_ent - NEW.qtde_sai + OLD.qtde_sai;
    
    -- Atualiza o saldo na tabela saldo_banco
    UPDATE saldo_banco SET saldo = saldo_atual WHERE id = NEW.id_saldo;
END;

